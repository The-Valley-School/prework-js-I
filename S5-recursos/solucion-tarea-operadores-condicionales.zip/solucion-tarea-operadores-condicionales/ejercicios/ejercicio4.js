/*  

Ejercicio 4 - PH Piscina

- Crea un fichero ejercicio4.js e inclúyelo dentro de tu html
- Define una variable llamada ph con un valor 7
- Crea una condición que muestre un mensaje por consola indicando que:
  > Si tienes un ph mayor o igual a 0 y menor que 7, el agua está ácida
  > Si tienes un ph igual a 7, el agua está neutra
  > Si tienes un ph mayor a 7 y menor o igual a 14, el agua está alcalina
  > Validar que si el ph no está entre 0 y 14, no es un ph correcto
- Prueba a cambiar el valor de la ph para comprobar que dependiendo del valor sale un mensaje u otro por consola.

*/

let ph = 7;

if(ph > 0 && ph <= 7) {
  console.log("El agua está ácida");
} else if (ph == 7) {
  console.log("El agua está neutra");
} else if (ph > 7 && ph <= 14) {
  console.log("El agua está alcalina");
} else {
  console.log("El ph no es correcto");
}
