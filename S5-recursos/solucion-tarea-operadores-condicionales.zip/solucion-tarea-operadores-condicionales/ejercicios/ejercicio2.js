/* Ejercicio 2 - Comida favorita


- Crea un fichero llamado ejercicio2.js e inclúyelo dentro de tu html
- Define una variable llamada ciudad y asígnale el valor de tu lugar favorito
- Define una variable llamada mejorAmigo y asígnale el nombre de tu mejor amigo.
- Define una variable llamada estacion donde indiques si eres más de verano, otoño…
- Muestra por consola la frase: “Me encanta XXX, me gustaría ir con XXX el próximo XXXX”

(por ejemplo ‘Me encanta Barcelona, me gustaría ir con Fran el próximo verano’) 

*/


let ciudad = "Barcelona";
let mejorAmigo = "Fran";
let estacion = "verano";

let mensaje = "Me encanta " + ciudad + ",me gustaría ir con " + mejorAmigo + " el próximo " + estacion; 
console.log(mensaje);