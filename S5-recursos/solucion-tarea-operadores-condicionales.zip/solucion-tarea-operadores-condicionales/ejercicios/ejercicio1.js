/*

Ejercicio 1 - Calculadora


- Crea un fichero llamado ejercicio1.js e inclúyelo dentro de tu html
- Define una variable llamada x y asígnale un valor 30
- Define una variable llamada y y asígnale un valor 40
- Utilizando el operador de suma y asignación, suma a la variable y el valor de x
- Utilizando el operador de resta y asignación, resta a la variable y el valor de x
- Utilizando el operador de multiplicación y asignación, multiplica la variable y el valor de x
- Utilizando el operador de division y asignación, divide la variable y el valor de x
- Ve mostrando los resultados por consola para poder ver que se ejecuta correctamente.

*/

let x = 30;
let y = 40;

y += x;
y -= x;
y /= x;
y *= x;

console.log(y);


