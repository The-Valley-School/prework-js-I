/*  

Ejercicio 3 - Conducir coche

- Crea un fichero llamado ejercicio3.js e inclúyelo dentro de tu html
- Define una variable llamada edad y asígnale un valor 18
- Define una variable tengoCarnet y asígnale un valor true
- Define una variable tengoCoche y asígnale un valor true
- Define una variable tengoMoto y asígnale un valor false
- Define una variable heBebidoAlcohol y asígnale un valor true
- Declara una variable puedoConducir donde comprobemos si tengo edad para conducir, tengo carnet, tengo coche o tengo moto, y no he bebido.
- Mostrar la variable puedoConducir por consola e ir probando las diferentes opciones

*/

let edad = 18;
let tengoCarnet = true;
let tengoCoche = true;
let tengoMoto = false;
let heBebidoAlcohol = true;

let puedoConducir = edad >= 18 && tengoCarnet && (tengoCoche || tengoMoto) && !heBebidoAlcohol;
console.log(puedoConducir);