/*  

Ejercicio 5 - Calculadora 3

- Crea un fichero ejercicio5.js e inclúyelo dentro de tu html
- Define una variable llamada a con valor 3
- Define una variable llamada b con valor 10
- Define una variable llamada operacion con valor SUMA
- Define una variable llamada resultado sin valor definido;
- En función de la variable operacion (SUMA, RESTA, DIVISIÓN, MULTIPLICACIÓN) realizar la operación con las variables a y b sobre la variable resultado [Ayuda: Hay que hacer un switch]
- En caso de que no sea ninguna de esas operaciones el resultado tiene que ser 0
- Mostrar por consola el resultado de la operación
- Probar con las diferentes opciones.

*/

let a = 3;
let b = 10;
let resultado;
let operacion = "SUMA";

switch (operacion){
    case "SUMA":
       resultado = a + b;
       break;
    case "RESTA":
       resultado = a - b;
       break;
    case "MULTIPLICACIÓN":
       resultado = a * b;
       break;
    case "DIVISIÓN":
       resultado = a / b;
       break;
    default:
        resultado = 0;
        break;
}

console.log(resultado);